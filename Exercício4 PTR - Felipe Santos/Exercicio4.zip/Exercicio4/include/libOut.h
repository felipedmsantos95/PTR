#ifndef LIBOUT_H
#define LIBOUT_H


//Y em funcao de x
double *Yt(double *x);

#endif

