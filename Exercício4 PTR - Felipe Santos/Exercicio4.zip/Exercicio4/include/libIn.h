#ifndef LIBIN_H
#define LIBIN_H

//Cálculo de x bola
double *dxt(double *x, double *u);

#endif

