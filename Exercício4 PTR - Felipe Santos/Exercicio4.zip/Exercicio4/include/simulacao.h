#ifndef SIMULACAO_H
#define SIMULACAO_H



char *nomeArquivo();

void abreArquivo();

void simulacao();


#endif

